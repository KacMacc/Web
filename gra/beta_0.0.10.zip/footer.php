<footer>
    Copyright &copy; 2018 Bazy Danych 2
</footer>