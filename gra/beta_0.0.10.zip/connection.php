<?php

$conn = new mysqli("localhost", "root", "", "pwrstar");
$conn->query("SET NAMES 'utf8' COLLATE 'utf8_polish_ci'");
$conn->query("SET CHARSET utf8");



?>